package com.example.blackout;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

public class BlackActivity extends Activity {
    private static final String TAG = "Blackout";
    private final StringBuilder errors = new StringBuilder();

    private interface Step { void run() throws Exception; }

    /** Run one setup step; if it fails, record the error and keep going. */
    private void step(String name, Step s) {
        try {
            s.run();
        } catch (Throwable t) {
            Log.e(TAG, name + " failed", t);
            errors.append(name).append(": ").append(t).append("\n");
        }
    }

    private void showText(FrameLayout root, String text) {
        TextView tv = new TextView(this);
        tv.setTextColor(Color.LTGRAY);
        tv.setTextSize(12);
        tv.setPadding(40, 120, 40, 40);
        tv.setGravity(Gravity.TOP);
        tv.setText(text);
        root.addView(tv);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        try {
            setup(root, b);
        } catch (Throwable t) {
            Log.e(TAG, "setup failed", t);
            showText(root, "setup failed: " + t);
        }
    }

    @SuppressWarnings("deprecation")
    private void setup(FrameLayout root, Bundle saved) {
        final DevicePolicyManager dpm = getSystemService(DevicePolicyManager.class);
        final ComponentName admin = new ComponentName(this, AdminReceiver.class);

        if (!dpm.isDeviceOwnerApp(getPackageName())) {
            showText(root, "Not device owner. Run set-device-owner first.");
            return;
        }

        SharedPreferences p = getSharedPreferences("p", MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long end;
        if (saved == null && getIntent().hasExtra("minutes")) {
            // fresh start from adb: always begin a new timer
            int minutes = getIntent().getIntExtra("minutes", 30);
            end = now + minutes * 60L * 1000L;
            p.edit().putLong("end", end).apply();
        } else {
            end = p.getLong("end", 0L);
            if (end == 0L) {
                end = now + 30 * 60L * 1000L;
                p.edit().putLong("end", end).apply();
            }
        }
        long left = end - now;
        if (left <= 0) {
            Release.run(this, this);
            finishAndRemoveTask();
            return;
        }

        step("setLockTaskPackages", () ->
                dpm.setLockTaskPackages(admin, new String[]{getPackageName()}));
        step("setLockTaskFeatures", () ->
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE));
        step("keyguard", () -> {
            if (!dpm.setKeyguardDisabled(admin, true)) {
                errors.append("keyguard: not disabled (set screen lock to None)\n");
            }
        });
        step("window", () -> {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = 0.01f;
            getWindow().setAttributes(lp);
        });
        step("immersive", () -> root.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE));
        step("startLockTask", () -> startLockTask());

        if (errors.length() > 0) {
            showText(root, "Setup problems:\n" + errors);
        }

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Release.run(BlackActivity.this, BlackActivity.this);
            finishAndRemoveTask();
        }, left);
    }
}
