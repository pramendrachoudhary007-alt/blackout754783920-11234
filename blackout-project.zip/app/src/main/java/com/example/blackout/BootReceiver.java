package com.example.blackout;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Emergency exit: any reboot (e.g. force restart) undoes the lockdown. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Release.run(context, null);
    }
}
