package com.example.blackout;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;

public class Release {
    /** Undo everything: unlock task mode, restore keyguard, drop device owner. */
    public static void run(Context c, Activity a) {
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().clear().apply();
        DevicePolicyManager dpm = c.getSystemService(DevicePolicyManager.class);
        ComponentName admin = new ComponentName(c, AdminReceiver.class);
        if (a != null) {
            try { a.stopLockTask(); } catch (Exception ignored) {}
        }
        try { dpm.setKeyguardDisabled(admin, false); } catch (Exception ignored) {}
        try { dpm.setLockTaskPackages(admin, new String[0]); } catch (Exception ignored) {}
        try { dpm.clearDeviceOwnerApp(c.getPackageName()); } catch (Exception ignored) {}
    }
}
